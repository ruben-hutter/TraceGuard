#!/bin/bash
# ccn-lite/test/scripts/paths.sh

#CCND_HOME=~/ccn-lite/ccnx-0.7.1
CCND_HOME=~/ccn-lite/ccnx-0.8.0
CCNL_HOME=~/ccn-lite/ccn-lite

# Use XEROX PUP as ethernet type:
CCNL_ETH_TYPE=0x0a00
