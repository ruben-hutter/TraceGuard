ccn-lite
========

CCN-lite is a lightweight implementation of Name Based Networking,
in particular:

- PARC's Content Centric Networking Protocol
  http://www.ccnx.org/

- the Named-Data Networking project (to come soon)
  http://named-data.net/  

- the Named-Function Networking project (to come soon)
  http://named-function.net/

CCN-lite has been included in the RIOT operating system
for the Internet of Things (IoT):
http://www.riot-os.org/

See also the ICN Research Group of the IRTF
https://irtf.org/icnrg

// eof
